# app.py

import streamlit as st
import joblib
import re
import string
import nltk
from nltk.corpus import stopwords

# Download stopwords
nltk.download('stopwords')

# Load model and vectorizer
model = joblib.load('spam_model.pkl')
vectorizer = joblib.load('vectorizer.pkl')

# Text preprocessing
def clean_text(text):
    text = text.lower()
    text = re.sub(r'\d+', '', text)
    text = text.translate(str.maketrans('', '', string.punctuation))
    text = text.strip()
    stop_words = set(stopwords.words('english'))
    text = ' '.join([word for word in text.split() if word not in stop_words])
    return text

# Streamlit UI
st.set_page_config(page_title="Email Spam Classifier", page_icon="📩")
st.title("📧 Email Spam Classifier")
st.markdown("### Classify your message as **Spam** or **Not Spam**")

# Input
message = st.text_area("Enter your message here")

# Button
if st.button("Classify"):
    if message.strip() == "":
        st.warning("⚠️ Please enter a message.")
    else:
        cleaned = clean_text(message)
        vect_message = vectorizer.transform([cleaned])
        prediction = model.predict(vect_message)[0]
        if prediction == 1:
            st.error("🚨 This is SPAM!")
        else:
            st.success("✅ This is NOT Spam.")
